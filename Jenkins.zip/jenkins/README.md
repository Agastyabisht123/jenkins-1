# Jenkins
A test repo for learning CI/CD 
```sh
Jenkins Server address : 3.84.99.95:8080
```
#### Parameters:
- EMAIL : To whom build notifcation to be sent
- NAME : Who is runnning build
        
> Server hosted on AWS EC2 

