from datetime import datetime as dt
from src.add import add


now = dt.now()
print("Commit at ", now)


